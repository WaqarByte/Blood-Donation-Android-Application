package com.waqar.BeDonor.Chat;

public class Contacts {

    public Contacts(){}
    public Contacts(String name, String bloodgroup, String profilepictureurl) {
        this.name = name;
        this.bloodgroup = bloodgroup;
        this.profilepictureurl = profilepictureurl;
    }

    public String name, bloodgroup, profilepictureurl;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBloodgroup() {
        return bloodgroup;
    }

    public void setBloodgroup(String bloodgroup) {
        this.bloodgroup = bloodgroup;
    }

    public String getProfilepictureurl() {
        return profilepictureurl;
    }

    public void setProfilepictureurl(String profilepictureurl) {
        this.profilepictureurl = profilepictureurl;
    }
}
