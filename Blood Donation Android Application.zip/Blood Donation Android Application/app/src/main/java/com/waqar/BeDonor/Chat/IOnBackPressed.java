package com.waqar.BeDonor.Chat;

public interface IOnBackPressed {
    boolean onBackPressed();
}
