package com.waqar.BeDonor;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import de.hdodenhof.circleimageview.CircleImageView;


public class Dashboard extends AppCompatActivity {


    CircleImageView userPhoto;
    TextView userName, userBloodGroup;
    private DatabaseReference userRef;
    CardView bloodDonationClick, pedometerClick, chatClick, FAQClick, shareClick, aboutUsClick;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        userPhoto = findViewById(R.id.dashboardUserPhotoId);
        userName = findViewById(R.id.dashboardUserNameId);
        userBloodGroup = findViewById(R.id.dashboardUserBloodGroupId);


        pedometerClick = findViewById(R.id.pedometerDashboardId);
        bloodDonationClick = findViewById(R.id.bloodDonationDashboardId);
        chatClick = findViewById(R.id.openChatDashboardId);
        FAQClick = findViewById(R.id.faqDashboardId);
        shareClick = findViewById(R.id.shareDashboardId);
        aboutUsClick = findViewById(R.id.aboutUsDashboardId);





        try {


            userRef = FirebaseDatabase.getInstance().getReference().child("users").child(
                    FirebaseAuth.getInstance().getCurrentUser().getUid()
            );


            userRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if (snapshot.exists()){

                        String name = snapshot.child("name").getValue().toString();
                        userName.setText(name);

                        String bloodgroup = snapshot.child("bloodgroup").getValue().toString();
                        userBloodGroup.setText(bloodgroup);


                        if (snapshot.hasChild("profilepictureurl")){
                            String imageUrl = snapshot.child("profilepictureurl").getValue().toString();
                            Glide.with(getApplicationContext()).load(imageUrl).into(userPhoto);
                        }else {
                            userPhoto.setImageResource(R.drawable.profile_image);
                        }


                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });
        }catch (Exception e){
            Toast.makeText(getApplicationContext(),"Error : "+ e, Toast.LENGTH_SHORT).show();
        }


























        pedometerClick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(getApplicationContext(), com.waqar.BeDonor.stepcounter.ui.MainActivity.class));
        }
        });
        bloodDonationClick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                intent.putExtra("openChatSection", "DonationSection");  // pass your values and retrieve them in the other Activity using keyName
                startActivity(intent);
            }
        });
        chatClick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


              //  startActivity(new Intent(getApplicationContext(), MainActivity.class));
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                intent.putExtra("openChatSection", "openChatSection");  // pass your values and retrieve them in the other Activity using keyName
                startActivity(intent);

//                fragmentLoader(new ChatMainFragment());


            }
        });
        FAQClick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(getApplicationContext(), FaqActivity.class));
            }
        });
        shareClick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

//

                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("text/plain");
                intent.putExtra(Intent.EXTRA_SUBJECT, "Be Donor");
                intent.putExtra(Intent.EXTRA_TEXT, "Hello there, Download the App if you need blood donor....");
                startActivity(Intent.createChooser(intent, "choose one"));
            }
        });

        aboutUsClick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(getApplicationContext(), AboutUsActivity.class));
            }
        });




    }
    private void fragmentLoader(Fragment fragment) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.main_frame_layout, fragment);
        fragmentTransaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        fragmentTransaction.commit();
    }
}