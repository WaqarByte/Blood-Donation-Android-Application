package com.waqar.BeDonor.stepcounter.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.waqar.BeDonor.R


class StepCounter : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_step_counter)
    }
}