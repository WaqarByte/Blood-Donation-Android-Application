package com.waqar.BeDonor.Chat;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;
import com.waqar.BeDonor.R;


import java.util.HashMap;

import de.hdodenhof.circleimageview.CircleImageView;

public class ChatProfileFragment extends Fragment {



    private String receiverUserId, senderUserId;
    private CircleImageView userProfileImage;
    private TextView userProfileName, userProfileStatus;
    private Button sendMessageRequestButton;
    private DatabaseReference userRef, chatRequestRef, contactsRef, notificationRef;
    private FirebaseAuth mAuth;

    public ChatProfileFragment() {
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.chat_profile_fragment, container, false);


        userRef = FirebaseDatabase.getInstance().getReference().child("users");
        chatRequestRef = FirebaseDatabase.getInstance().getReference().child("Chat Requests");
        contactsRef = FirebaseDatabase.getInstance().getReference().child("Contacts");
        notificationRef = FirebaseDatabase.getInstance().getReference().child("Notifications");

        mAuth = FirebaseAuth.getInstance();
        senderUserId = mAuth.getCurrentUser().getUid();

        //receiverUserId = getActivity().getIntent().getExtras().get("visitUserId").toString();
        receiverUserId = getArguments().getString("visitUserId");


        userProfileImage = view.findViewById(R.id.visit_profile_image);
        userProfileName =  view.findViewById(R.id.visit_user_name);
        userProfileStatus =view.findViewById(R.id.visit_profile_status);
        sendMessageRequestButton = view.findViewById(R.id.send_message_request_button);

        sendMessageRequestButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SendChatRequest();
            }
        });

        RetrieveUserInfo();


        return view;
    }


    private void RetrieveUserInfo() {

        if(senderUserId.equals(receiverUserId)){
            sendMessageRequestButton.setEnabled(false);
            sendMessageRequestButton.setVisibility(View.INVISIBLE);
        }

        userRef.child(receiverUserId).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                if ((dataSnapshot.exists()) && (dataSnapshot.hasChild("profilepictureurl"))) {
                    String userImage = dataSnapshot.child("profilepictureurl").getValue().toString();
                    Picasso.get().load(userImage).placeholder(R.drawable.profile_image).into(userProfileImage);
                }

                String userName = dataSnapshot.child("name").getValue().toString();
                String userStatus = dataSnapshot.child("bloodgroup").getValue().toString();

                userProfileName.setText(userName);
                userProfileStatus.setText(userStatus);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }

    private void SendChatRequest() {
        if(sendMessageRequestButton.getText().equals("Cancel Invited")){
            chatRequestRef.child(senderUserId).child(receiverUserId)
                    .removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if(task.isSuccessful()){
                        chatRequestRef.child(receiverUserId).child(senderUserId)
                                .removeValue();
                    }
                }
            });
            sendMessageRequestButton.setText(R.string.add_friend);
            return;
        }
        chatRequestRef.child(senderUserId).child(receiverUserId)
                .child("requestType").setValue("sent")
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            chatRequestRef.child(receiverUserId).child(senderUserId)
                                    .child("requestType").setValue("received")
                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if (task.isSuccessful()) {
                                                HashMap<String, String> chatNotificationMap = new HashMap<>();
                                                chatNotificationMap.put("from", senderUserId);
                                                chatNotificationMap.put("type", "request");
                                                notificationRef.child(receiverUserId).push()
                                                        .setValue(chatNotificationMap);
                                                sendMessageRequestButton.setText(R.string.cancel_invite);
                                            }
                                        }
                                    });
                        }
                    }
                });
    }




}