package com.waqar.BeDonor


import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.waqar.BeDonor.Adapter.FaqAdapter
import com.waqar.BeDonor.databinding.ActivityFaqBinding

//import com.waqar.myapplication.databinding.ActivityMainBinding
//import com.waqar.myapplication.databinding.FaqActivityBinding

class FaqActivity : AppCompatActivity() {

    // view binding for the activity
    private var _binding: ActivityFaqBinding? = null
    private val binding get() = _binding!!

    // get reference to the adapter class
    private var faqHolderList = ArrayList<FAQHolder>()
    private lateinit var faqAdapter: FaqAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        _binding = ActivityFaqBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // define layout manager for the Recycler view
        binding.rvList.layoutManager = LinearLayoutManager(this)

        // attach adapter to the recycler view
        faqAdapter = FaqAdapter(faqHolderList)
        binding.rvList.adapter = faqAdapter

        // create new objects
        // add some row data
        val faqHolder1 = FAQHolder(
            "What is Blood Donation? ",
            "Java is an Object Oriented Programming language." +
                    " Java is used in all kind of applications like Mobile Applications (Android is Java based), " +
                    "desktop applications, web applications, client server applications, enterprise applications and many more. ",
            false
        )
        val faqHolder2 = FAQHolder(
            "Who can Donate Blood?",
            "In most states, donors must be age 17 or older." +
                    " Some states allow donation by 16-year-olds with a signed parental consent form." +
                    "Donors must weigh at least 110 pounds and be in good health. Additional eligibility criteria apply.",
            false
        )
        val faqHolder3 = FAQHolder(
            "How often can i donate blood?",
            "You must wait at least eight weeks (56 days) between donations" +
                    " of whole blood and 16 weeks (112 days) between Power Red donations." +
                    " Whole blood donors can donate up to 6 times a year. Platelet apheresis" +
                    "donors may give every 7 days up to 24 times per year." +
                    "Regulations are different for those giving blood for themselves (autologous donors).",
            false
        )
        val faqHolder4 = FAQHolder(
            "How long does a blood donation take?",
            "The entire process takes about one hour and 15 minutes;" +
                    "the actual donation of a pint of whole blood unit takes eight to 10 minutes." +
                    " However, the time varies slightly with each person depending on several factors" +
                    " including the donor’s health history and attendance at the blood drive.",
              false
        )
val faqHolder5 = FAQHolder(
            "How long will it take to recover the pint of blood I donate? ",
            "",
            false
        )
        val faqHolder6 = FAQHolder(
            "Will it hurt when you insert the needle? ",
            "Only for a moment. Pinch the fleshy, soft underside of your arm." +
                    " That pinch is similar to what you will feel when the needle is inserted.",
            false
        )

        // add items to list
        faqHolderList.add(faqHolder1)
        faqHolderList.add(faqHolder2)
        faqHolderList.add(faqHolder3)
        faqHolderList.add(faqHolder4)
        faqHolderList.add(faqHolder5)
        faqHolderList.add(faqHolder6)

        faqAdapter.notifyDataSetChanged()

    }

    // on destroy of view make the binding reference to null
    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }
}
