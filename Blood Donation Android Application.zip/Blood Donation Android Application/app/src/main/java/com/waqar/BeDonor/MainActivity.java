package com.waqar.BeDonor;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import com.etebarian.meowbottomnavigation.MeowBottomNavigation;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.waqar.BeDonor.Adapter.UserAdapter;
import com.waqar.BeDonor.BottomNavigationFragments.AccountFragment;
import com.waqar.BeDonor.BottomNavigationFragments.FragmentHome;
import com.waqar.BeDonor.BottomNavigationFragments.NotificationFragment;
import com.waqar.BeDonor.BottomNavigationFragments.categorySelectedFragment;
import com.waqar.BeDonor.Chat.ChatMainFragment;
import com.waqar.BeDonor.Chat.IOnBackPressed;
import com.waqar.BeDonor.Model.User;
import com.waqar.BeDonor.R;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener{


    private DatabaseReference userRef;
    private DrawerLayout drawerLayout;
    private Toolbar toolbar;
    private NavigationView nav_view;

    private CircleImageView nav_profile_image;
    private TextView nav_fullname, nav_email, nav_bloodgroup, nav_type;


    private List<User> userList;
    private UserAdapter userAdapter;
    private FirebaseUser currentUser;
    private FirebaseAuth mAuth;
    private DatabaseReference rootRef;
    private String currentUserId;





    //Bottom navigation
    MeowBottomNavigation bottomNavigation;
    private final int ID_HOME = 1;
    private final int ID_MESSAGE = 2;
    private final int ID_NOTIFICATION = 3;
    private final int ID_ACCOUNT = 4;

    Bundle bundle;
boolean homeFragmentStatus=false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setTitle("Blood Donation App");

        drawerLayout = findViewById(R.id.drawerLayout);
        nav_view = findViewById(R.id.nav_view);

        mAuth = FirebaseAuth.getInstance();
        currentUser = mAuth.getCurrentUser();
        rootRef = FirebaseDatabase.getInstance().getReference();


        bundle = new Bundle();


        //Bottom navigation


        TextView selected_page = findViewById(R.id.selected_page);
        bottomNavigation = findViewById(R.id.bottomNagivation);

        bottomNavigation.add(new MeowBottomNavigation.Model(ID_HOME, R.drawable.ic_home));
        bottomNavigation.add(new MeowBottomNavigation.Model(ID_MESSAGE, R.drawable.ic_message));
        bottomNavigation.add(new MeowBottomNavigation.Model(ID_NOTIFICATION, R.drawable.ic_notification));
        bottomNavigation.add(new MeowBottomNavigation.Model(ID_ACCOUNT, R.drawable.ic_account));


        String data="";
        if (getIntent().getExtras()!= null){
            data = getIntent().getExtras().getString("openChatSection", "defaultKey");
        }

     //   String data = getIntent().getExtras().getString("openChatSection", "defaultKey");


        if (data.equals("openChatSection")) {


            bottomNavigation.setOnShowListener(new MeowBottomNavigation.ShowListener(){
                @Override
                public void onShowItem(MeowBottomNavigation.Model item) {


                    String name;
                    switch (item.getId()){
                        case ID_HOME:name ="Message";
                            break;
                        case ID_MESSAGE:name ="Message";
                            break;
                        case ID_NOTIFICATION:name ="Notification";
                            break;
                        case ID_ACCOUNT:name ="Account";
                            break;
                        default: name="Message";
                    }
                    //  selected_page.setText(getString(R.string.main_page_selected, name));


                }
            });
            bottomNavigation.show(ID_MESSAGE, true);
            fragmentLoader(new ChatMainFragment());
        } else {
            bottomNavigation.setOnShowListener(new MeowBottomNavigation.ShowListener(){
                @Override
                public void onShowItem(MeowBottomNavigation.Model item) {


                    String name;
                    switch (item.getId()){
                        case ID_HOME:name ="Message";
                            break;
                        case ID_MESSAGE:name ="Message";
                            break;
                        case ID_NOTIFICATION:name ="Notification";
                            break;
                        case ID_ACCOUNT:name ="Account";
                            break;
                        default: name="Message";
                    }
                    //  selected_page.setText(getString(R.string.main_page_selected, name));


                }
            });
            bottomNavigation.show(ID_HOME, true);
            fragmentLoader(new FragmentHome());



        }



        bottomNavigation.setOnClickMenuListener(new MeowBottomNavigation.ClickListener(){

            @Override
            public void onClickItem(MeowBottomNavigation.Model item){

                switch (item.getId()){
                    case 1:
//                         Toast.makeText(MainActivity.this, "home", Toast.LENGTH_SHORT).show();
                        fragmentLoader(new FragmentHome());
                        break;
                    case 2:
                        fragmentLoader(new ChatMainFragment());
                        break;
                    case 3:
                        fragmentLoader(new NotificationFragment());
                        break;
                    case 4:
                        fragmentLoader(new AccountFragment());
                        break;


                }

                //Fragment fragment = new Fragment();
//                switch (item.getId()){
//                    case 1:
//                        Toast
//                }

//                Home home = new Home();
//                fragmentLoader(home);

            }

        });



        bottomNavigation.setOnShowListener(new MeowBottomNavigation.ShowListener(){
            @Override
            public void onShowItem(MeowBottomNavigation.Model item) {


                String name;
                switch (item.getId()){
                    case ID_HOME:name ="Home";
                        break;
                    case ID_MESSAGE:name ="Message";
                        break;
                    case ID_NOTIFICATION:name ="Notification";
                        break;
                    case ID_ACCOUNT:name ="Account";
                        break;
                    default: name="";
                }
                //  selected_page.setText(getString(R.string.main_page_selected, name));


            }
        });
        bottomNavigation.setOnReselectListener(new MeowBottomNavigation.ReselectListener() {
            @Override
            public void onReselectItem(MeowBottomNavigation.Model item) {
                try{
                    Log.d("BottomNav", " reselector" );
                }catch (Exception error){
                    Log.d("BottomNav", "onReselectItem: " + error);
                }
            }
        });

        bottomNavigation.setCount(ID_NOTIFICATION, "4");
//        bottomNavigation.show(ID_HOME, true);



//        TextView selected_page = findViewById(R.id.selected_page);
//        MeowBottomNavigation bottomNavigation = findViewById(R.id.bottomNagivation);
//
//        bottomNavigation.add(new MeowBottomNavigation.Model(ID_HOME, R.drawable.ic_home));
//        bottomNavigation.add(new MeowBottomNavigation.Model(ID_MESSAGE, R.drawable.ic_message));
//        bottomNavigation.add(new MeowBottomNavigation.Model(ID_NOTIFICATION, R.drawable.ic_notification));
//        bottomNavigation.add(new MeowBottomNavigation.Model(ID_ACCOUNT, R.drawable.ic_account));
//
//
//        bottomNavigation.setOnClickMenuListener(new MeowBottomNavigation.ClickListener(){
//
//            @Override
//            public void onClickItem(MeowBottomNavigation.Model item){
//                Toast.makeText(MainActivity.this, "clicked item :" + item.getId(), Toast.LENGTH_SHORT).show();
//
//            }
//
//        });
//
//
//
//        bottomNavigation.setOnShowListener(new MeowBottomNavigation.ShowListener(){
//            @Override
//            public void onShowItem(MeowBottomNavigation.Model item) {
//
//                String name;
//                switch (item.getId()){
//                    case ID_HOME:name ="Home";
//                        break;
//                    case ID_MESSAGE:name ="Message";
//                        break;
//                    case ID_NOTIFICATION:name ="Notification";
//                        break;
//                    case ID_ACCOUNT:name ="Account";
//                        break;
//                    default: name="";
//                }
//                selected_page.setText(getString(R.string.main_page_selected, name));
//
//
//            }
//        });
//
//        bottomNavigation.setCount(ID_NOTIFICATION, "4");
//        bottomNavigation.show(ID_HOME, true);












        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(MainActivity.this, drawerLayout,
                toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);


        toggle.syncState();


        nav_view.setNavigationItemSelectedListener(this);

//        progressbar = findViewById(R.id.progressbar);
//
//        recyclerView = findViewById(R.id.recyclerView);
//        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
//        layoutManager.setReverseLayout(true);
//        layoutManager.setStackFromEnd(true);
//        recyclerView.setLayoutManager(layoutManager);
//
//        userList = new ArrayList<>();
//        userAdapter = new UserAdapter(MainActivity.this, userList);
//
//        recyclerView.setAdapter(userAdapter);
//
//        DatabaseReference ref = FirebaseDatabase.getInstance().getReference()
//                .child("users").child(FirebaseAuth.getInstance().getCurrentUser().getUid());
//        ref.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//              String type = snapshot.child("type").getValue().toString();
//              if (type.equals("donor")){
//                  readRecipients();
//              }else {
//                  readDonors();
//              }
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//
//            }
//        });




        nav_profile_image = nav_view.getHeaderView(0).findViewById(R.id.nav_user_image);
        nav_fullname = nav_view.getHeaderView(0).findViewById(R.id.nav_user_fullname);
        nav_email = nav_view.getHeaderView(0).findViewById(R.id.nav_user_email);
        nav_bloodgroup = nav_view.getHeaderView(0).findViewById(R.id.nav_user_bloodgroup);
        nav_type = nav_view.getHeaderView(0).findViewById(R.id.nav_user_type);


        try {


            userRef = FirebaseDatabase.getInstance().getReference().child("users").child(
                    FirebaseAuth.getInstance().getCurrentUser().getUid()
            );


            userRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if (snapshot.exists()){

                        String name = snapshot.child("name").getValue().toString();
                        nav_fullname.setText(name);

                        String email = snapshot.child("email").getValue().toString();
                        nav_email.setText(email);

                        String bloodgroup = snapshot.child("bloodgroup").getValue().toString();
                        nav_bloodgroup.setText(bloodgroup);

                        String type = snapshot.child("type").getValue().toString();
                        nav_type.setText(type);


                        if (snapshot.hasChild("profilepictureurl")){
                            String imageUrl = snapshot.child("profilepictureurl").getValue().toString();
                            Glide.with(getApplicationContext()).load(imageUrl).into(nav_profile_image);
                        }else {
                            nav_profile_image.setImageResource(R.drawable.profile_image);
                        }

                        Menu nav_menu = nav_view.getMenu();

                        if (type.equals("donor")){
                            nav_menu.findItem(R.id.sentEmail).setTitle("Received Emails");
                            nav_menu.findItem(R.id.notifications).setVisible(true);
                        }

                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });
        }catch (Exception e){
            Toast.makeText(getApplicationContext(),"Error : "+ e, Toast.LENGTH_SHORT).show();
        }

    }

    @Override
    protected void onStart(){
        super.onStart();

        FirebaseUser currentUser = mAuth.getCurrentUser();

        if(currentUser == null){
//            SendUserToLoginActivity();
        }
        else{

//            VerifyUserExistance();
            updateUserStatus("online");


//            String data = getIntent().getExtras().getString("openChatSection","defaultKey");
//            if (data.isEmpty()){
//
//            }else{
//
//
//
//                        bottomNavigation.performClick();
//
//                        fragmentLoader(new ChatMainFragment());
//
//
////                View view = bottomNavigation.findViewById(R.id.bottomNagivation);
////                view.performClick();
////                fragmentLoader(new ChatMainFragment());
//
//            }





        }
    }

//
//    private void readDonors() {
//        DatabaseReference reference = FirebaseDatabase.getInstance().getReference()
//                .child("users");
//        Query query = reference.orderByChild("type").equalTo("donor");
//        query.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                userList.clear();
//                for (DataSnapshot dataSnapshot : snapshot.getChildren()){
//                    User user = dataSnapshot.getValue(User.class);
//                    userList.add(user);
//                }
//                userAdapter.notifyDataSetChanged();
//                progressbar.setVisibility(View.GONE);
//
//                if (userList.isEmpty()){
//                    Toast.makeText(MainActivity.this, "No recipients", Toast.LENGTH_SHORT).show();
//                    progressbar.setVisibility(View.GONE);
//                }
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//
//            }
//        });
//    }
//
//    private void readRecipients() {
//        DatabaseReference reference = FirebaseDatabase.getInstance().getReference()
//                .child("users");
//        Query query = reference.orderByChild("type").equalTo("recipient");
//        query.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//              userList.clear();
//              for (DataSnapshot dataSnapshot : snapshot.getChildren()){
//                  User user = dataSnapshot.getValue(User.class);
//                  userList.add(user);
//              }
//              userAdapter.notifyDataSetChanged();
//              progressbar.setVisibility(View.GONE);
//
//              if (userList.isEmpty()){
//                  Toast.makeText(MainActivity.this, "No recipients", Toast.LENGTH_SHORT).show();
//                  progressbar.setVisibility(View.GONE);
//              }
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//
//            }
//        });
//    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){

            case R.id.aplus:


                bundle.putString("group", "A+");
// set Fragmentclass Arguments
                categorySelectedFragment fragobj = new categorySelectedFragment();
                fragobj.setArguments(bundle);
                fragmentLoader(fragobj);
                SettingDatatoToolbar("A+");
                break;

            case R.id.aminus:
                bundle.putString("group", "A-");
                categorySelectedFragment fragobj2 = new categorySelectedFragment();
                fragobj2.setArguments(bundle);
                fragmentLoader(fragobj2);
                SettingDatatoToolbar("A-");
                break;
            case R.id.bplus:
                bundle.putString("group", "B+");
                categorySelectedFragment fragobj3 = new categorySelectedFragment();
                fragobj3.setArguments(bundle);
                fragmentLoader(fragobj3);
                SettingDatatoToolbar("B+");


                break;

            case R.id.bminus:
                bundle.putString("group", "B-");
                categorySelectedFragment fragobj4 = new categorySelectedFragment();
                fragobj4.setArguments(bundle);
                fragmentLoader(fragobj4);
                SettingDatatoToolbar("B-");

                break;
            case R.id.abplus:
                bundle.putString("group", "AB+");
                categorySelectedFragment fragobj5 = new categorySelectedFragment();
                fragobj5.setArguments(bundle);
                fragmentLoader(fragobj5);
                SettingDatatoToolbar("AB+");

                break;
            case R.id.abminus:
                bundle.putString("group", "AB-");
                categorySelectedFragment fragobj6 = new categorySelectedFragment();
                fragobj6.setArguments(bundle);
                fragmentLoader(fragobj6);
                SettingDatatoToolbar("AB-");

                break;
            case R.id.oplus:
                bundle.putString("group", "O+");
                categorySelectedFragment fragobj7 = new categorySelectedFragment();
                fragobj7.setArguments(bundle);
                fragmentLoader(fragobj7);
                SettingDatatoToolbar("O+");
                break;
            case R.id.ominus:
                bundle.putString("group", "O-");
                categorySelectedFragment fragobj8 = new categorySelectedFragment();
                fragobj8.setArguments(bundle);
                fragmentLoader(fragobj8);
                SettingDatatoToolbar("O-");
                break;

            case R.id.compatible:
                Intent intent14 = new Intent(MainActivity.this, NotificationsActivity.class);
                startActivity(intent14);
                break;

            case R.id.notifications:
                Intent intent13 = new Intent(MainActivity.this, NotificationsActivity.class);
                startActivity(intent13);
                break;

            case R.id.sentEmail:
                Intent intent12 = new Intent(MainActivity.this, SentEmailActivity.class);
                startActivity(intent12);
                break;


            case R.id.profile:
                Intent intent = new Intent(MainActivity.this, ProfileActivity.class);
                startActivity(intent);
                break;

            case R.id.logout:
                FirebaseAuth.getInstance().signOut();
                Intent intent2 = new Intent(MainActivity.this, LoginActivity.class);
                startActivity(intent2);
                break;
        }
        drawerLayout.closeDrawer(GravityCompat.START);

        return true;




    }

    private void updateUserStatus(String state){
        String saveCurrentUserTime, saveCurrentUserDate;
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat currentDate  = new SimpleDateFormat("MMM dd, yyyy");
        saveCurrentUserDate = currentDate.format(calendar.getTime());
        SimpleDateFormat currentTime  = new SimpleDateFormat("hh:mm ss");
        saveCurrentUserTime = currentTime.format(calendar.getTime());

        HashMap<String, Object> onlineStateMap = new HashMap<>();

        onlineStateMap.put("time", saveCurrentUserTime);
        onlineStateMap.put("date", saveCurrentUserDate);
        onlineStateMap.put("state", state);

        currentUserId = currentUser.getUid();
        rootRef.child("users").child(currentUserId).child("userState")
                .updateChildren(onlineStateMap);

    }

    private void fragmentLoader(Fragment fragment) {

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
//        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.replace(R.id.main_frame_layout, fragment);
        fragmentTransaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        fragmentTransaction.commit();
    }

    public void SettingDatatoToolbar( String ToolbarData){
        this.getSupportActionBar().setTitle(ToolbarData);

    }

//    @Override
//    public void onBackPressed() {
////        super.onBackPressed();
//        if (homeFragmentStatus==true){
//            finish();
//        }
//
//        if (getSupportFragmentManager().getBackStackEntryCount() ==0) {
//            // dLayout.closeDrawers();
//            homeFragmentStatus=false;
//            finish();
//        }
//            else
//        {
//            homeFragmentStatus=true;
//          fragmentLoader(new FragmentHome());
//
//        }
//    }
@Override public void onBackPressed() {
    Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.main_frame_layout);
    if (!(fragment instanceof IOnBackPressed) || !((IOnBackPressed) fragment).onBackPressed()) {
        super.onBackPressed();
    }
}

}