package com.waqar.BeDonor.Chat;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabItem;
import com.google.android.material.tabs.TabLayout;
import com.waqar.BeDonor.R;


public class ChatMainFragment extends Fragment {


    public ChatMainFragment() {
        // Required empty public constructor
    }


    TabLayout tabLayout;
    TabItem tabItem1,tabItem2,tabItem3;
    ViewPager viewPager;
    ChatPageAdapter chatPageAdapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.chat_main_fragment, container, false);


        tabLayout=(TabLayout)view.findViewById(R.id.tablayout1);
        tabItem1=(TabItem)view.findViewById(R.id.tab1);
        tabItem2=(TabItem)view.findViewById(R.id.tab2);
        tabItem3=(TabItem)view.findViewById(R.id.tab3);
        viewPager=(ViewPager)view.findViewById(R.id.vpager);





        chatPageAdapter=new ChatPageAdapter(getActivity().getSupportFragmentManager(),tabLayout.getTabCount());
        viewPager.setAdapter(chatPageAdapter);

        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager.setCurrentItem(tab.getPosition());

                if(tab.getPosition()==0 || tab.getPosition()==1 || tab.getPosition()==2)
                    chatPageAdapter.notifyDataSetChanged();
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });


        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
        //listen for scroll or page change




        return view;
    }

}