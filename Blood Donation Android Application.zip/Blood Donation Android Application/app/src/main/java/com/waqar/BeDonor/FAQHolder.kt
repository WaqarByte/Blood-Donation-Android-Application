package com.waqar.BeDonor
// this is the Language model class
class FAQHolder(
    val name : String ="",
    val description : String= "",
    var expand : Boolean = false
)
