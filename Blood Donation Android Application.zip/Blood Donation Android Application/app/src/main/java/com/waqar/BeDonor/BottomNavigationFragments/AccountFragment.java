package com.waqar.BeDonor.BottomNavigationFragments;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.waqar.BeDonor.R;


import de.hdodenhof.circleimageview.CircleImageView;


public class AccountFragment extends Fragment {

//    private Toolbar toolbar;
    private TextView type, name, email, idNumber, phoneNumber, bloodGroup, location;
    private CircleImageView profileImage;
    private Button backButton;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_account, container, false);



//        toolbar = view.findViewById(R.id.toolbar);
//        setSupportActionBar(toolbar);
//        getSupportActionBar().setTitle("My Profile");
//        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
//        getSupportActionBar().setDisplayShowHomeEnabled(true);

        type = view.findViewById(R.id.type);
        name = view.findViewById(R.id.name);
        email = view.findViewById(R.id.email);
        idNumber = view.findViewById(R.id.idNumber);
        phoneNumber = view.findViewById(R.id.phoneNumber);
        location = view.findViewById(R.id.location);
        bloodGroup = view.findViewById(R.id.bloodGroup);
        profileImage = view.findViewById(R.id.profileImage);
        backButton = view.findViewById(R.id.backButton);

        DatabaseReference reference = FirebaseDatabase.getInstance().getReference()
                .child("users").child(FirebaseAuth.getInstance().getCurrentUser().getUid());

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()){
                    type.setText(snapshot.child("type").getValue().toString());
                    name.setText(snapshot.child("name").getValue().toString());
                    idNumber.setText(snapshot.child("idnumber").getValue().toString());
                    phoneNumber.setText(snapshot.child("phonenumber").getValue().toString());
                    location.setText(snapshot.child("location").getValue().toString());
                    bloodGroup.setText(snapshot.child("bloodgroup").getValue().toString());
                    email.setText(snapshot.child("email").getValue().toString());

                    if (getActivity() != null) {
                        Glide.with(getContext()).load(snapshot.child("profilepictureurl").getValue().toString()).into(profileImage);
                    }

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

//        backButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
////                Intent intent  = new Intent(ProfileActivity.this, MainActivity.class);
////                startActivity(intent);
//                finish();
//            }
//        });





        return  view;
    }

//    @Override
//    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
//
//        switch (item.getItemId()){
//            case android.R.id.home:
//                finish();
//                return  true;
//            default:
//                return super.onOptionsItemSelected(item);
//        }
//
//
//
//
//
//
//        return view;
//
//    }
}