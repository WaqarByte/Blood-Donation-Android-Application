package com.waqar.BeDonor.Email;

public class Util {
    // Add your own email and password over here.
    public  static  final String EMAIL = "blooddonationmail@gmail.com";
    public static final String PASSWORD = "BloodDonationMail@6t67t78t8";
}
