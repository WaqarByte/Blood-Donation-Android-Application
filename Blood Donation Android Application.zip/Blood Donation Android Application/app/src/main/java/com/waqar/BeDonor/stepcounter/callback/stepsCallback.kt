package com.waqar.BeDonor.stepcounter.callback

interface stepsCallback {

    fun subscribeSteps(steps: Int)
}