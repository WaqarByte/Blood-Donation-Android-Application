package com.waqar.BeDonor.stepcounter.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.core.content.ContextCompat
import com.waqar.BeDonor.R
//import com.daniyalak.stepcounterkotlin_androidfitnessapp.R
import com.waqar.BeDonor.stepcounter.callback.stepsCallback
import com.waqar.BeDonor.stepcounter.helper.GeneralHelper
import com.waqar.BeDonor.stepcounter.service.StepDetectorService

import kotlinx.android.synthetic.main.step_counter_activity.*

//import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity(), stepsCallback {
    //    lateinit var TV_STEPS: TextView
//    lateinit var TV_CALORIES: TextView
//    lateinit var TV_DISTANCE: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.step_counter_activity)
        //If write permission is not allowed request user to allow
//        if (!hasPermission) {
//            ActivityCompat.requestPermissions(this,
//                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
//                    REQUEST_WRITE_STORAGE);
//        }

//        TV_STEPS = findViewById(R.id.TV_STEPS) as TextView
//        TV_CALORIES = findViewById(R.id.TV_CALORIES) as TextView
//        TV_DISTANCE = findViewById(R.id.TV_DISTANCE) as TextView
        if (ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.ACTIVITY_RECOGNITION
                ) == PackageManager.PERMISSION_DENIED
        ) {
            //ask for permission
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(arrayOf(Manifest.permission.ACTIVITY_RECOGNITION), 23)
            }
        }
        val intent = Intent(this, StepDetectorService::class.java)
        startService(intent)

        StepDetectorService.subscribe.register(this)

    }

    override fun subscribeSteps(steps: Int) {
        TV_STEPS.setText(steps.toString())
        TV_CALORIES.setText(GeneralHelper.getCalories(steps))
        TV_DISTANCE.setText(GeneralHelper.getDistanceCovered(steps))
    }
}